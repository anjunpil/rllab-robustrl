### Example 1
In this example, we train a (64,64) net policy on the swimmer environment and . This is just to show an example. Typically, we need to train longer (for approx 250 or 300 iterations).

